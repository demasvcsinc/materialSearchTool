import './style.css';
import React, { useState, useMemo } from 'react';
import { initializeBlock, useBase, useRecords, CellRenderer, expandRecord, useCustomProperties } from '@airtable/blocks/interface/ui';
import { MagnifyingGlassIcon, XIcon, DownloadSimpleIcon } from '@phosphor-icons/react';
import { Base, Table, Field, FieldConfig } from '@airtable/blocks/interface/models';

function getCustomProperties(base: Base) {
    const coTable = base.getTableByIdIfExists('tblPTD3AmkCFCkr2n') ?? base.tables.find(t => t.name.toLowerCase().includes('co material'));
    const azTable = base.getTableByIdIfExists('tblAMuQfvP7sy2GZr') ?? base.tables.find(t => t.name.toLowerCase().includes('az material'));
    
    return [
        {
            key: 'coMaterialPacksTable',
            label: 'CO materials',
            type: 'table' as const,
            defaultValue: coTable,
        },
        {
            key: 'azMaterialPacksTable',
            label: 'AZ materials',
            type: 'table' as const,
            defaultValue: azTable,
        },
    ];
}

interface RecordWithSource {
    record: ReturnType<typeof useRecords>[number];
    source: 'CO' | 'AZ';
    table: Table;
    productIdField: Field | null;
    descriptionField: Field | null;
    modelProfileField: Field | null;
    qtyField: Field | null;
    unitPriceField: Field | null;
    totalCostField: Field | null;
    phaseField: Field | null;
}

function MaterialSearchApp(): React.ReactElement {
    const base = useBase();
    const { customPropertyValueByKey } = useCustomProperties(getCustomProperties);
    
    const coTable = customPropertyValueByKey.coMaterialPacksTable as Table | undefined;
    const azTable = customPropertyValueByKey.azMaterialPacksTable as Table | undefined;
    
    const coRecords = useRecords(coTable ?? null);
    const azRecords = useRecords(azTable ?? null);
    
    const [searchQuery, setSearchQuery] = useState('');

    const coProductIdField = coTable?.getFieldIfExists('fldaR7uo7ATOPLVZN') ?? null;
    const coDescriptionField = coTable?.getFieldIfExists('fldW62H3wcSxBDDUw') ?? null;
    const coModelProfileField = coTable?.getFieldIfExists('fldq5wCr9HGV6boBC') ?? null;
    const coQtyField = coTable?.getFieldIfExists('fldjEXgFR2YfdSSuD') ?? null;
    const coUnitPriceField = coTable?.getFieldIfExists('fldBTjc6PcSAM1TO6') ?? null;
    const coTotalCostField = coTable?.getFieldIfExists('fldr1ldjGkl2wKoso') ?? null;
    const coPhaseField = coTable?.getFieldIfExists('fldzKJqzABwRvfUnj') ?? null;

    const azProductIdField = azTable?.getFieldIfExists('fld52uQo50L9w0OIb') ?? null;
    const azDescriptionField = azTable?.getFieldIfExists('fld0GBiW9QortpgAV') ?? null;
    const azModelProfileField = azTable?.getFieldIfExists('fldA7kGFaiNJBBg8X') ?? null;
    const azQtyField = azTable?.getFieldIfExists('fldaV2YSHepJpc0CY') ?? null;
    const azUnitPriceField = azTable?.getFieldIfExists('fldTV7riKyMURZBbo') ?? null;
    const azTotalCostField = azTable?.getFieldIfExists('fldsG4MojnzDUTuqs') ?? null;
    const azPhaseField = azTable?.getFieldIfExists('fld0Bq6D5ZOJ8X0ZO') ?? null;

    const canExpandCoRecords = coTable?.hasPermissionToExpandRecords() ?? false;
    const canExpandAzRecords = azTable?.hasPermissionToExpandRecords() ?? false;

    const allRecordsWithSource: RecordWithSource[] = useMemo(() => {
        const combined: RecordWithSource[] = [];
        
        if (coTable) {
            coRecords.forEach(record => {
                combined.push({
                    record,
                    source: 'CO',
                    table: coTable,
                    productIdField: coProductIdField,
                    descriptionField: coDescriptionField,
                    modelProfileField: coModelProfileField,
                    qtyField: coQtyField,
                    unitPriceField: coUnitPriceField,
                    totalCostField: coTotalCostField,
                    phaseField: coPhaseField,
                });
            });
        }
        
        if (azTable) {
            azRecords.forEach(record => {
                combined.push({
                    record,
                    source: 'AZ',
                    table: azTable,
                    productIdField: azProductIdField,
                    descriptionField: azDescriptionField,
                    modelProfileField: azModelProfileField,
                    qtyField: azQtyField,
                    unitPriceField: azUnitPriceField,
                    totalCostField: azTotalCostField,
                    phaseField: azPhaseField,
                });
            });
        }
        
        return combined;
    }, [coRecords, azRecords, coTable, azTable, coProductIdField, coDescriptionField, coModelProfileField, coQtyField, coUnitPriceField, coTotalCostField, coPhaseField, azProductIdField, azDescriptionField, azModelProfileField, azQtyField, azUnitPriceField, azTotalCostField, azPhaseField]);

    const filteredRecords = useMemo(() => {
        if (!searchQuery.trim()) {
            return [];
        }

        const query = searchQuery.toLowerCase().trim();
        const queryTerms = query.split(/\s+/).filter(term => term.length > 0);

        return allRecordsWithSource.filter(item => {
            const { record, productIdField, descriptionField, modelProfileField, qtyField, unitPriceField, totalCostField, phaseField } = item;
            
            const productId = productIdField ? record.getCellValueAsString(productIdField).toLowerCase() : '';
            const description = descriptionField ? record.getCellValueAsString(descriptionField).toLowerCase() : '';
            const modelProfile = modelProfileField ? record.getCellValueAsString(modelProfileField).toLowerCase() : '';
            const qty = qtyField ? record.getCellValueAsString(qtyField).toLowerCase() : '';
            const unitPrice = unitPriceField ? record.getCellValueAsString(unitPriceField).toLowerCase() : '';
            const totalCost = totalCostField ? record.getCellValueAsString(totalCostField).toLowerCase() : '';
            const phase = phaseField ? record.getCellValueAsString(phaseField).toLowerCase() : '';

            const searchableText = `${productId} ${description} ${modelProfile} ${qty} ${unitPrice} ${totalCost} ${phase}`;

            return queryTerms.every(term => searchableText.includes(term));
        });
    }, [allRecordsWithSource, searchQuery]);

    const handleExportCSV = () => {
        if (filteredRecords.length === 0) return;

        const headerRow = ['Source', 'Phase', 'Product ID', 'Description', 'QTY', 'Unit Price (PPU)', 'Total Cost', 'Model Profile'].map(col => `"${col}"`).join(',');

        const dataRows = filteredRecords.map(item => {
            const { record, source, productIdField, descriptionField, modelProfileField, qtyField, unitPriceField, totalCostField, phaseField } = item;
            
            const values = [
                source,
                phaseField ? record.getCellValueAsString(phaseField) : '',
                productIdField ? record.getCellValueAsString(productIdField) : '',
                descriptionField ? record.getCellValueAsString(descriptionField) : '',
                qtyField ? record.getCellValueAsString(qtyField) : '',
                unitPriceField ? record.getCellValueAsString(unitPriceField) : '',
                totalCostField ? record.getCellValueAsString(totalCostField) : '',
                modelProfileField ? record.getCellValueAsString(modelProfileField) : '',
            ];
            
            return values.map(value => `"${value.replace(/"/g, '""')}"`).join(',');
        });

        const csvContent = [headerRow, ...dataRows].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        link.setAttribute('href', url);
        link.setAttribute('download', `material_search_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleClearSearch = () => {
        setSearchQuery('');
    };

    const handleRecordClick = (item: RecordWithSource) => {
        const canExpand = item.source === 'CO' ? canExpandCoRecords : canExpandAzRecords;
        if (canExpand) {
            expandRecord(item.record);
        }
    };

    if (!coTable && !azTable) {
        return (
            <div className="flex items-center justify-center h-screen bg-gray-gray50 dark:bg-gray-gray800">
                <div className="text-center p-6">
                    <p className="text-gray-gray500 dark:text-gray-gray400 mb-2">No tables configured</p>
                    <p className="text-sm text-gray-gray400 dark:text-gray-gray500">Please configure the CO and AZ Material Packs tables in the properties panel.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-gray50 dark:bg-gray-gray800 p-4 sm:p-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-6">
                    <h1 className="text-2xl font-display font-bold text-gray-gray800 dark:text-gray-gray100 mb-2">
                        Material Search
                    </h1>
                    <p className="text-sm text-gray-gray500 dark:text-gray-gray400">
                        Search by Product ID, Description, or keywords across CO and AZ Material Packs
                    </p>
                </div>

                <div className="relative mb-6">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <MagnifyingGlassIcon className="h-5 w-5 text-gray-gray400" />
                    </div>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search materials (e.g., SHWR BSE, product ID, description)..."
                        className="w-full pl-11 pr-10 py-3 bg-white dark:bg-gray-gray700 border border-gray-gray200 dark:border-gray-gray600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-blue text-gray-gray800 dark:text-gray-gray100 placeholder-gray-gray400"
                    />
                    {searchQuery && (
                        <button
                            onClick={handleClearSearch}
                            className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-gray400 hover:text-gray-gray600 dark:hover:text-gray-gray300"
                        >
                            <XIcon className="h-5 w-5" />
                        </button>
                    )}
                </div>

                {searchQuery.trim() && (
                    <div className="mb-4 flex justify-between items-center">
                        <p className="text-sm text-gray-gray500 dark:text-gray-gray400">
                            {filteredRecords.length} result{filteredRecords.length !== 1 ? 's' : ''} found
                        </p>
                        {filteredRecords.length > 0 && (
                            <button
                                onClick={handleExportCSV}
                                className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-blue-blue hover:text-blue-blueDark1 dark:text-blue-blueLight1 dark:hover:text-blue-blueLight2 transition-colors"
                            >
                                <DownloadSimpleIcon className="h-4 w-4" />
                                Export Results
                            </button>
                        )}
                    </div>
                )}

                {!searchQuery.trim() && (
                    <div className="flex flex-col items-center justify-center py-16 text-center">
                        <MagnifyingGlassIcon className="h-12 w-12 text-gray-gray300 dark:text-gray-gray500 mb-4" />
                        <p className="text-gray-gray500 dark:text-gray-gray400 mb-2">Enter a search term to find materials</p>
                        <p className="text-sm text-gray-gray400 dark:text-gray-gray500">Search by Product ID, Description, or any keyword</p>
                    </div>
                )}

                <div className="space-y-3">
                    {filteredRecords.map(item => (
                        <div
                            key={`${item.source}-${item.record.id}`}
                            onClick={() => handleRecordClick(item)}
                            className="bg-white dark:bg-gray-gray700 rounded-lg shadow-sm border border-gray-gray100 dark:border-gray-gray600 p-4 cursor-pointer hover:shadow-md transition-all"
                        >
                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                                            item.source === 'CO' 
                                                ? 'bg-green-greenLight2 text-green-greenDark1 dark:bg-green-greenDark1 dark:text-green-greenLight1' 
                                                : 'bg-orange-orangeLight2 text-orange-orangeDark1 dark:bg-orange-orangeDark1 dark:text-orange-orangeLight1'
                                        }`}>
                                            {item.source}
                                        </span>
                                        {item.productIdField && (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-sm font-medium bg-blue-blueLight2 text-blue-blueDark1 dark:bg-blue-blueDark1 dark:text-blue-blueLight1">
                                                <CellRenderer record={item.record} field={item.productIdField} />
                                            </span>
                                        )}
                                        {item.phaseField && (
                                            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-gray100 text-gray-gray600 dark:bg-gray-gray600 dark:text-gray-gray200">
                                                <CellRenderer record={item.record} field={item.phaseField} />
                                            </span>
                                        )}
                                    </div>
                                    {item.descriptionField && (
                                        <div className="text-base font-medium text-gray-gray800 dark:text-gray-gray100 mb-1">
                                            <CellRenderer record={item.record} field={item.descriptionField} />
                                        </div>
                                    )}
                                    <div className="text-xs text-gray-gray400 dark:text-gray-gray500 flex flex-wrap gap-x-4 gap-y-1">
                                        {item.modelProfileField && (
                                            <span>Model: <CellRenderer record={item.record} field={item.modelProfileField} /></span>
                                        )}
                                        {item.qtyField && (
                                            <span>QTY: <CellRenderer record={item.record} field={item.qtyField} /></span>
                                        )}
                                    </div>
                                </div>
                                <div className="text-right shrink-0">
                                    {item.totalCostField && (
                                        <div className="text-base font-semibold text-gray-gray800 dark:text-gray-gray100">
                                            <CellRenderer record={item.record} field={item.totalCostField} />
                                        </div>
                                    )}
                                    {item.unitPriceField && (
                                        <div className="text-xs text-gray-gray400 dark:text-gray-gray500">
                                            PPU: <CellRenderer record={item.record} field={item.unitPriceField} />
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {searchQuery.trim() && filteredRecords.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-16 text-center">
                        <p className="text-gray-gray500 dark:text-gray-gray400 mb-2">No results found</p>
                        <p className="text-sm text-gray-gray400 dark:text-gray-gray500">Try adjusting your search terms</p>
                    </div>
                )}
            </div>
        </div>
    );
}

initializeBlock({ interface: () => <MaterialSearchApp /> });